package auth

const (
	URL = "https://sessionserver.mojang.com/session/minecraft/hasJoined?username=%s&serverId=%s"
)
