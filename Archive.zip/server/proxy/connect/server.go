package connect

type Server struct {
	Name string
	Addr string
	SecurityKey string
}
