package connect

type RedirectHandler func(server string, player string)
