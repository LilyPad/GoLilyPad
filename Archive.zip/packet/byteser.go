package packet

type Byteser interface {
	Bytes() []byte
}
