package packet

type Packet interface {
	Id() int
}
