package packet

type PacketRaw interface {
	Raw() bool
}
