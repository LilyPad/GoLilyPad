package connect

type EventHandler func(event Event)
