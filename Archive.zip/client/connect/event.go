package connect

type Event interface {

}
